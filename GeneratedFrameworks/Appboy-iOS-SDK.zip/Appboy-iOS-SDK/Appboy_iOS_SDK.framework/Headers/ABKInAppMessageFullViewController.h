#import "ABKInAppMessageImmersiveViewController.h"

NS_ASSUME_NONNULL_BEGIN
@interface ABKInAppMessageFullViewController : ABKInAppMessageImmersiveViewController

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *closeXButtonTopConstraint;

@end
NS_ASSUME_NONNULL_END
