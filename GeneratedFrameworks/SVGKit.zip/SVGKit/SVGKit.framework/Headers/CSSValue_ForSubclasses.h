#import <Foundation/Foundation.h>

@interface CSSValue()

- (id)initWithUnitType:(CSSUnitType) t;

@end
