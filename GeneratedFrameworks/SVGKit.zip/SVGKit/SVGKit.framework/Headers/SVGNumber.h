/*!

 http://www.w3.org/TR/SVG/types.html#InterfaceSVGNumber
 
 interface SVGNumber {
 attribute float value setraises(DOMException);
 };
 */
typedef struct
{
	float value;
} SVGNumber;
